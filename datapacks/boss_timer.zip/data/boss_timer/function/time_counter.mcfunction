scoreboard players add counter tickcount 1
execute if score counter tickcount matches 20 run scoreboard players remove bar bossbar 1
execute store result bossbar boss:main value run scoreboard players get bar bossbar
execute store result score hour hour run scoreboard players get bar bossbar
execute store result score snap hour run scoreboard players get bar bossbar
execute if score counter tickcount matches 20 run scoreboard players operation hour hour /= number3600 setnumber
execute if score counter tickcount matches 20 run scoreboard players operation snap hour %= number3600 setnumber
execute store result score min min run scoreboard players get snap hour
execute store result score snap min run scoreboard players get snap hour
execute if score counter tickcount matches 20 run scoreboard players operation min min /= number60 setnumber
execute if score counter tickcount matches 20 run scoreboard players operation snap min %= number60 setnumber
execute store result score sec sec run scoreboard players get snap min
execute if score counter tickcount matches 20 if score hour hour < number10 setnumber if score min min >= number10 setnumber if score sec sec >= number10 setnumber run bossbar set boss:main name {"text": "距離下次重啟","extra": [{"text": "0"},{"score": {"name": "hour","objective": "hour"}},{"text": ":"},{"score": {"name": "min","objective": "min"}},{"text": ":"},{"score": {"name": "sec","objective": "sec"}}]}
execute if score counter tickcount matches 20 if score hour hour < number10 setnumber if score min min < number10 setnumber if score sec sec >= number10 setnumber run bossbar set boss:main name {"text": "距離下次重啟","extra": [{"text": "0"},{"score": {"name": "hour","objective": "hour"}},{"text": ":0"},{"score": {"name": "min","objective": "min"}},{"text": ":"},{"score": {"name": "sec","objective": "sec"}}]}
execute if score counter tickcount matches 20 if score hour hour < number10 setnumber if score min min >= number10 setnumber if score sec sec < number10 setnumber run bossbar set boss:main name {"text": "距離下次重啟","extra": [{"text": "0"},{"score": {"name": "hour","objective": "hour"}},{"text": ":"},{"score": {"name": "min","objective": "min"}},{"text": ":0"},{"score": {"name": "sec","objective": "sec"}}]}
execute if score counter tickcount matches 20 if score hour hour < number10 setnumber if score min min < number10 setnumber if score sec sec < number10 setnumber run bossbar set boss:main name {"text": "距離下次重啟","extra": [{"text": "0"},{"score": {"name": "hour","objective": "hour"}},{"text": ":0"},{"score": {"name": "min","objective": "min"}},{"text": ":0"},{"score": {"name": "sec","objective": "sec"}}]}
execute if score counter tickcount matches 20 run scoreboard players set counter tickcount 0