bossbar remove boss:main
scoreboard objectives add bossbar dummy
scoreboard players set bar bossbar 18000
scoreboard objectives add tickcount dummy
scoreboard players set counter tickcount 0
scoreboard objectives add setnumber dummy
scoreboard players set number20 setnumber 20
scoreboard players set number300 setnumber 300
scoreboard players set number0 setnumber 0
scoreboard players set number60 setnumber 60
scoreboard players set number3600 setnumber 3600
scoreboard players set number10 setnumber 10
scoreboard objectives add hour dummy
scoreboard players set hour hour 0
scoreboard players set snap hour 0
scoreboard objectives add min dummy
scoreboard players set min min 0
scoreboard players set snap min 0
scoreboard objectives add sec dummy
scoreboard players set sec sec 0
bossbar add boss:main "距離下次重啟"
bossbar set boss:main name {"text": "距離下次重啟","extra": [{"score": {"name": "hour","objective": "hour"}},{"text": ":"},{"score": {"name": "min","objective": "min"}},{"text": ":"},{"score": {"name": "sec","objective": "sec"}}]}
bossbar set boss:main max 18000
bossbar set boss:main value 18000
bossbar set boss:main players @a